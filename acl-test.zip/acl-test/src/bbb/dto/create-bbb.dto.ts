export class CreateBbbDto {}
